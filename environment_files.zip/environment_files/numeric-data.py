myValue = 1

print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))
print("Python has three numeric types: int, float, and complex")

name = input("What is your name?")
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))